#!/bin/bash

# Renk kodları
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Bodur Oto Kurtarma Web Sitesi Kurulum Scripti${NC}"
echo "=================================================="

# Root kontrolü
if [ "$EUID" -ne 0 ]; then 
    echo "Bu script root yetkisi gerektirmektedir."
    echo "Lütfen 'sudo ./install.sh' şeklinde çalıştırın."
    exit 1
fi

# Gerekli paketlerin kurulumu
echo -e "\n${GREEN}1. Gerekli paketler kuruluyor...${NC}"
apt update
apt install -y python3-pip python3-venv nginx

# Proje dizininin oluşturulması
echo -e "\n${GREEN}2. Proje dizini oluşturuluyor...${NC}"
PROJECT_DIR="/var/www/bodur"
mkdir -p $PROJECT_DIR
cp -r * $PROJECT_DIR/
cd $PROJECT_DIR

# Python sanal ortamının kurulumu
echo -e "\n${GREEN}3. Python sanal ortamı kuruluyor...${NC}"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Nginx yapılandırması
echo -e "\n${GREEN}4. Nginx yapılandırması yapılıyor...${NC}"
cp bodur.nginx /etc/nginx/sites-available/bodur
ln -sf /etc/nginx/sites-available/bodur /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Systemd servis dosyasının kurulumu
echo -e "\n${GREEN}5. Systemd servis dosyası kuruluyor...${NC}"
cp bodur.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable bodur
systemctl start bodur

# Nginx yeniden başlatılıyor
echo -e "\n${GREEN}6. Nginx yeniden başlatılıyor...${NC}"
systemctl restart nginx

# SSL sertifikası kurulumu için bilgi
echo -e "\n${GREEN}7. SSL Sertifikası Kurulumu${NC}"
echo "SSL sertifikası kurmak için aşağıdaki komutu çalıştırın:"
echo "sudo certbot --nginx -d siteniz.com -d www.siteniz.com"

# Kurulum tamamlandı
echo -e "\n${GREEN}Kurulum tamamlandı!${NC}"
echo "Web sitesine http://localhost veya http://sunucu-ip-adresiniz üzerinden erişebilirsiniz."
echo "Hata ayıklama için logları kontrol edin:"
echo "- Uygulama logları: sudo journalctl -u bodur"
echo "- Nginx logları: sudo tail -f /var/log/nginx/error.log"
