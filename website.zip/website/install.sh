#!/bin/bash

# Renk kodları
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Bodur Oto Kurtarma Web Sitesi Kurulum Scripti - Amazon Linux${NC}"
echo "=================================================="

# Root kontrolü
if [ "$EUID" -ne 0 ]; then 
    echo "Bu script root yetkisi gerektirmektedir."
    echo "Lütfen 'sudo ./install.sh' şeklinde çalıştırın."
    exit 1
fi

# Amazon Linux sürüm kontrolü
if ! grep -q "Amazon Linux" /etc/os-release; then
    echo "Bu script sadece Amazon Linux sistemlerde çalışır."
    exit 1
fi

# Gerekli paketlerin kurulumu
echo -e "\n${GREEN}1. Gerekli paketler kuruluyor...${NC}"
yum update -y
yum install -y python3 python3-pip nginx

# EPEL repository ekleme
amazon-linux-extras install -y epel
yum install -y certbot python3-certbot-nginx

# Proje dizininin oluşturulması
echo -e "\n${GREEN}2. Proje dizini oluşturuluyor...${NC}"
PROJECT_DIR="/var/www/bodur"
mkdir -p $PROJECT_DIR
cp -r * $PROJECT_DIR/
cd $PROJECT_DIR

# Python sanal ortamının kurulumu
echo -e "\n${GREEN}3. Python sanal ortamı kuruluyor...${NC}"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Nginx yapılandırması
echo -e "\n${GREEN}4. Nginx yapılandırması yapılıyor...${NC}"
# SELinux ayarları (eğer aktifse)
if command -v sestatus >/dev/null 2>&1; then
    setsebool -P httpd_can_network_connect 1
fi

# Nginx config
cat > /etc/nginx/conf.d/bodur.conf << 'EOL'
server {
    listen 80;
    server_name _;  # Tüm hostları dinle

    location = /favicon.ico { access_log off; log_not_found off; }
    
    location /static/ {
        alias /var/www/bodur/website/static/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
        access_log off;
    }

    location / {
        include proxy_params;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_pass http://unix:/var/www/bodur/bodur.sock;
    }
}
EOL

# Proxy parametreleri için ek yapılandırma
cat > /etc/nginx/proxy_params << 'EOL'
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header X-Forwarded-Host $server_name;
proxy_set_header Host $http_host;
proxy_redirect off;
proxy_buffering off;
EOL

rm -f /etc/nginx/conf.d/default.conf

# Systemd servis dosyasının oluşturulması
echo -e "\n${GREEN}5. Systemd servis dosyası oluşturuluyor...${NC}"
cat > /etc/systemd/system/bodur.service << 'EOL'
[Unit]
Description=Bodur Oto Kurtarma Web Sitesi
After=network.target

[Service]
User=nginx
WorkingDirectory=/var/www/bodur
Environment="PATH=/var/www/bodur/venv/bin"
ExecStart=/var/www/bodur/venv/bin/gunicorn --workers 3 --bind unix:bodur.sock -m 007 app:app

[Install]
WantedBy=multi-user.target
EOL

# İzinlerin ayarlanması
echo -e "\n${GREEN}6. İzinler ayarlanıyor...${NC}"
chown -R nginx:nginx $PROJECT_DIR
chmod -R 755 $PROJECT_DIR
find $PROJECT_DIR/website/static -type f -exec chmod 644 {} \;
find $PROJECT_DIR/website/static -type d -exec chmod 755 {} \;

# Servislerin başlatılması
echo -e "\n${GREEN}7. Servisler başlatılıyor...${NC}"
systemctl daemon-reload
systemctl enable bodur
systemctl start bodur
systemctl enable nginx
systemctl restart nginx

# Firewall ayarları
echo -e "\n${GREEN}8. Firewall ayarları yapılıyor...${NC}"
if command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --permanent --add-service=http
    firewall-cmd --permanent --add-service=https
    firewall-cmd --reload
fi

# Kurulum tamamlandı
echo -e "\n${GREEN}Kurulum tamamlandı!${NC}"
echo "Web sitesine http://sunucu-ip-adresiniz üzerinden erişebilirsiniz."
echo ""
echo "SSL sertifikası kurmak için:"
echo "sudo certbot --nginx -d siteniz.com -d www.siteniz.com"
echo ""
echo "Hata ayıklama için logları kontrol edin:"
echo "- Uygulama logları: sudo journalctl -u bodur"
echo "- Nginx logları: sudo tail -f /var/log/nginx/error.log"
echo ""
echo "Not: Amazon EC2 güvenlik grubunuzda 80 ve 443 portlarının açık olduğundan emin olun."
